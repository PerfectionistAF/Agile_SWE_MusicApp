<?php


declare(strict_types=1);


namespace Payment;


use SplObjectStorage;


class PaymentMethods implements \Stringable

{
    private $attribute_vals;

    public function __construct(private string $name, array $attribute_vals)

    {

        $this->attribute_vals = new SplObjectStorage();


        foreach ($attribute_vals as $value) {

            $this->attribute_vals->attach($value);

        }

    }


    public function __toString(): string

    {

        $str = [$this->name];


        foreach ($this->attribute_vals as $value) {

            $str[] = (string) $value;

        }


        return join(', ', $str);

    }

}
?>