<?php


declare(strict_types=1);


namespace Payment;



class PMethod_Attr_Values implements \Stringable

{
    public function __construct(private Pmethod_Attr $attr, private string $name)

    {
        $attr->addVal($this);
    }

    public function __toString(): string

    {
        return sprintf('%s: %s', (string) $this->attr, $this->name);
    }

}

?>