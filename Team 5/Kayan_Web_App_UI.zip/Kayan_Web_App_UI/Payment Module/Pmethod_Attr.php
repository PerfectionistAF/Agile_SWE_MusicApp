<?php


declare(strict_types=1);


namespace Payment;


use SplObjectStorage;


class Pmethod_Attr implements \Stringable

{

    private SplObjectStorage $attribute_vals;


    public function __construct(private string $name)

    {

        $this->attribute_vals = new SplObjectStorage();

    }


    public function addVal(PMethod_Attr_Values $val): void

    {

        $this->attribute_vals->attach($val);

    }


    public function getVals(): SplObjectStorage

    {

        return $this->attribute_vals;

    }


    public function __toString(): string

    {

        return $this->name;

    }

}
?>