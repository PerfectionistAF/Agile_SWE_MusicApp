The payment module was created according to the Entity-Attribute-Variable (EAV) format stated in the Lecture 9 slides.
Language: PHP

Entity -> PaymentMethods.php
Attribute -> Pmethod_Attr.php
Value -> PMethod_Attr_values.php

Complementary MySQL table declarations are included in "PaymentModuleSQLTables.txt"




////////////***************************************\\\\\\\\\\\\\\\\\




The html files for two webpages are also included. "Payment Options.html" is the first page in the payment module. It displays 3 
payment options: Vodafone cash, credit card, fawry pay.
-If the credit card option is selected, you will be redirected to "Credit Card Information Page.html" to enter relevant credit card info.
-If vodafone cash is selected, the number registered while applying should be used to pay (provided that it is a vodafone number).
-If fawry is selected, you should be redirected to the fawry payment system.




----------IMPORTANT----------
!!! To implement actual credit card payments, we would have needed to register to a 3DS certification from Europay-MasterCard-Visa (EMV)
which is outside the scope of our project.

!!!To implement Vodafone cash and fawry pay, we need a deployed and commercially registered website and then the owners of the business
could register to obtain the services which is outside the scope of our project. 




////////////***************************************\\\\\\\\\\\\\\\\\


There is also a Receipt.php
