 <?php
class Receipt {

  private $firstname;
  private $lastname;
  private $cost;
  private $date;
  private $payment_method;
  

  function set_firstname($firstname) {
    $this->firstname = $firstname;
  }
  function set_lastname($lastname) {
    $this->lastname = $lastname;
  }
  function get_firstname() {
    return $this->firstname;
  }
  function get_lastname() {
    return $this->lastname;
  }
  function set_cost($cost) {
    $this->cost = $cost;
  }
  function get_cost() {
    return $this->cost;
  }
  function set_date($date) {
    $this->date = $date;
  }
  function get_date() {
    return $this->date;
  }
  function set_payment_method($payment_method) {
    $this->payment_method = $payment_method;
  }
  function get_payment_method() {
    return $this->payment_method;
  }
  
}
?>